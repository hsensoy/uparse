import sys
import os

assert len(sys.argv) == 2

print os.path.splitext(sys.argv[1])[0]
