package org.maltparser.parser.history.action;

/**
*
* @author Johan Hall
**/
public interface ActionDecision {
	public void clear();
}
