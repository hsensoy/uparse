package org.maltparser.core.feature.function;
/**
*
*
* @author Johan Hall
*/
public interface FeatureMapFunction extends FeatureFunction {

}
