package org.maltparser.core.feature.function;

public interface FeatureCastFunction extends FeatureFunction {

}
