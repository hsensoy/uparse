package org.maltparser.core.syntaxgraph.headrules;
/**
*
*
* @author Johan Hall
*/
public enum Direction {
	LEFT, RIGHT
}
