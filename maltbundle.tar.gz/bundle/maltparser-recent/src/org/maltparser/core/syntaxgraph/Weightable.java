package org.maltparser.core.syntaxgraph;
/**
*
*
* @author Johan Hall
*/
public interface Weightable {
	public void setWeight(double weight);
	public double getWeight();
}
