/**
 * 
 */
package experiments;

/**
 * @author miguel
 *
 */
public class ExperimentLastRoot {
	
	public ExperimentLastRoot() {
		
	}
	
	
	public void generateModifiedCorpus(String inputCorpus) {
		
		//SEE PERL FIL
		
		
	}

}
