import sys
__author__ = 'husnusensoy'

def optioniter(file):
    with open(file, "r") as fp:
        for line in fp:
            option = line.strip().split(' ')[-1]
            o, v = option.split(':')
            o = o.replace(")", "").replace("(", "")

            yield (o, v)

if __name__ == "__main__":
    optdict = dict((o, v) for o, v in optioniter("phase3_optFile.txt"))
    sys.stdout.write(optdict["-F"])
